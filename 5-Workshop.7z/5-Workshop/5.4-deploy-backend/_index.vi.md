---
title : "Triển khai Backend"
date :  "2025-09-15" 
weight : 4 
chapter : false
pre : " <b> 5.4. </b> "
---

#### Deploy Backend với AWS SAM

Trong phần này, chúng ta sẽ sử dụng SAM Template để deploy toàn bộ hạ tầng lên AWS.

#### Các bước

1. Build với Maven (compile Java)

2. Build với SAM (package Lambda)
      
3. Deploy với SAM (tạo CloudFormation stack)
      
4. Verify Resources (kiểm tra trên AWS Console)