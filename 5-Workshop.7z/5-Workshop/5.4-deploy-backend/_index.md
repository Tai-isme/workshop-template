---
title : "Deploy Backend"
date :  "2025-09-15" 
weight : 4 
chapter : false
pre : " <b> 5.4. </b> "
---

#### Deploy Backend with AWS SAM

In this section, we will use a SAM Template to deploy the entire infrastructure to AWS.

#### Steps

1. Build with Maven (compile Java)

2. Build with SAM (package Lambda)
      
3. Deploy with SAM (create CloudFormation stack)
      
4. Verify Resources (check on the AWS Console)



